﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("C2M - Call of Duty BSP Extractor")]
[assembly: AssemblyDescription("Extracts BSP Data from Call of Duty")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("SHEILAN")]
[assembly: AssemblyProduct("C2M")]
[assembly: AssemblyCopyright("Copyright © SHEILAN")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("bbeb0978-d656-4432-80e9-cf2083f53349")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.4.2")]
[assembly: AssemblyFileVersion("1.0.4.2")]
